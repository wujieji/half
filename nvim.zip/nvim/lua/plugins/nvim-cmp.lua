return {
    "hrsh7th/nvim-cmp",
    dependencies = {
        "hrsh7th/cmp-nvim-lsp",
        "hrsh7th/cmp-buffer",
        "hrsh7th/cmp-path",
        "hrsh7th/cmp-cmdline",
        "hrsh7th/cmp-vsnip",
        "onsails/lspkind-nvim",
        -- For luasnip users.
        "L3MON4D3/LuaSnip",
        "saadparwaiz1/cmp_luasnip"
    },
    config = function()
        local cmp = require("cmp")
        local lspkind = require("lspkind")
        cmp.setup({
            -- 指定 snippet 引擎
            snippet = {
                expand = function(args)
                    -- For `vsnip` users.
                    -- vim.fn["vsnip#anonymous"](args.body)

                    -- For `luasnip` users.
                    require('luasnip').lsp_expand(args.body)

                    -- For `ultisnips` users.
                    -- vim.fn["UltiSnips#Anon"](args.body)

                    -- For `snippy` users.
                    -- require'snippy'.expand_snippet(args.body)
                end,
            },
            -- 来源
            sources = {
                { name = "nvim_lsp" },
                -- For vsnip users.
                { name = "vsnip" },
                -- For luasnip users.
                -- { name = 'luasnip' },
                --For ultisnips users.
                -- { name = 'ultisnips' },
                -- -- For snippy users.
                -- { name = 'snippy' },
                { name = "buffer" },
                { name = "path" },
            },
            -- 快捷键
            mapping = require("config.keybindings").cmp(cmp),
            -- 使用lspkind-nvim显示类型图标
            formatting = {
                format = lspkind.cmp_format({
                    with_text = true, -- do not show text alongside icons
                    maxwidth = 50,    -- prevent the popup from showing more than provided characters (e.g 50 will not show more than 50 characters)
                    before = function(entry, vim_item)
                        -- Source 显示提示来源
                        vim_item.menu = "[" .. string.upper(entry.source.name) .. "]"
                        return vim_item
                    end,
                }),
            },
        })

        -- Use buffer source for `/`.
        cmp.setup.cmdline("/", {
            sources = {
                { name = "buffer" },
            },
        })

        -- Use cmdline & path source for ':'.
        cmp.setup.cmdline(":", {
            sources = cmp.config.sources({
                { name = "path" },
            }, {
                { name = "cmdline" },
            }),
        })
    end,
}
